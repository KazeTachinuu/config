# Memory Allocator Implementation Guide

## Overview

Coucou mon coeur, je t'ai fait ce petit guide pour que tu ne soit pas perdu dans ce projet qui est plutot fun en vrai.
Ce n'est ABSOLUMENT pas la seule facon de le faire et il y a meme surement des choses pas folles.
Mais tu peux le suivre comme un tuto.
Bon courage Love you.
Normalement ca ressemble pas trop a mon implementation donc ca devrait etre good mais feel free de changer ce que tu veux.
You got this :)

## 1. Project Overview and Files Structure

```
── src/
   ├── bucket.c    (Main implementation)
   ├── bucket.h    (Core structures and interfaces)
   ├── utils.h     (Helper functions)
   └── malloc.c    (Standard interface wrappers)
```

## 2. Key Components Implementation Guide

### Step 1: Basic Bucket Management (`bucket.c`)

#### allocate_meta_page Implementation:
```c
static struct bucket *allocate_meta_page(void) {
    /* TODO Implementation Steps:
     * 1. Check/initialize pagesize if not done
     * 2. Use mmap:
     *    - NULL for address (let system choose)
     *    - pagesize for length
     *    - PROT_READ | PROT_WRITE for protection
     *    - MAP_PRIVATE | MAP_ANONYMOUS for flags
     *    - -1 for fd, 0 for offset
     * 3. Check for MAP_FAILED
     * 4. Return the new page
     */
}
```

Key Concepts:
- System pages are the basic unit of memory allocation
- mmap creates a new memory mapping
- Protection flags control memory access
- Anonymous mapping means not backed by a file

#### allocate_chunk_area Implementation:
```c
static void *allocate_chunk_area(size_t total_size) {
    /* TODO Implementation Steps:
     * 1. Use mmap similar to meta_page
     * 2. Ensure size is aligned to page size
     * 3. Handle allocation failures
     * 4. Return the allocated area
     */
}
```

Key Concepts:
- Chunk areas must be aligned to page boundaries
- Size must accommodate all chunks plus alignment
- Error handling is critical

### Step 2: Core Memory Management Functions

#### my_malloc Implementation:
```c
void *my_malloc(size_t size) {
    /* TODO Implementation Steps:
     * 1. Handle special cases:
     *    - Check for zero size
     *    - Align requested size
     * 
     * 2. Determine allocation type:
     *    - If size > max_bucket_size → large allocation
     *    - Otherwise → bucket allocation
     * 
     * 3. For bucket allocation:
     *    a. Calculate bucket index
     *    b. Find/create appropriate bucket
     *    c. Find free chunk in bucket
     *    d. Mark chunk as used in bitmap
     *    e. Update statistics
     * 
     * 4. For large allocation:
     *    a. Calculate total size including metadata
     *    b. Allocate memory with mmap
     *    c. Initialize metadata
     *    d. Update statistics
     * 
     * 5. Return pointer to allocated memory
     */
}
```

Bitmap Management Tips:
- Each bit in bitmap represents one chunk
- Byte index = chunk_index / 8
- Bit index = chunk_index % 8
- Set bit: bitmap[byte] |= (1 << bit)
- Clear bit: bitmap[byte] &= ~(1 << bit)

#### my_free Implementation:
```c
void my_free(void *ptr) {
    /* TODO Implementation Steps:
     * 1. Handle NULL pointer
     * 
     * 2. Find allocation type:
     *    - Iterate through buckets
     *    - Check if ptr belongs to each bucket
     *    - If not found → large allocation
     * 
     * 3. For bucket allocation:
     *    a. Calculate chunk index
     *    b. Verify chunk is actually allocated
     *    c. Clear bitmap bit
     *    d. Update used_chunks counter
     *    e. Update statistics
     * 
     * 4. For large allocation:
     *    a. Locate metadata block
     *    b. Verify metadata
     *    c. Calculate total size
     *    d. Use munmap to free
     *    e. Update statistics
     */
}
```

#### my_realloc Implementation:
```c
void *my_realloc(void *ptr, size_t size) {
    /* TODO Implementation Steps:
     * 1. Handle special cases:
     *    - NULL pointer → malloc
     *    - Zero size → free
     * 
     * 2. Find current allocation:
     *    - Determine if bucket or large
     *    - Get current size
     * 
     * 3. Compare sizes:
     *    - If new size <= current → return ptr
     *    - Otherwise → need new allocation
     * 
     * 4. For new allocation:
     *    a. Allocate new block
     *    b. Copy data (using smaller of old/new size)
     *    c. Free old block
     *    d. Return new pointer
     */
}
```

### Step 3: Thread Safety Implementation

Thread safety is handled at two levels:
1. Large allocations use mutex:
```c
pthread_mutex_lock(&mgr.large_lock);
// Perform large allocation/free
pthread_mutex_unlock(&mgr.large_lock);
```

2. Bucket allocations are naturally thread-safe:
- Each bucket operates independently
- Bitmap operations are atomic
- No shared state between buckets

### Step 4: Memory Alignment and Safety

Alignment rules:
- All allocations must be aligned to sizeof(long double)
- Page allocations must be aligned to page size
- Use align_size() utility function

Safety checks:
- Always check for integer overflow
- Validate pointer operations
- Verify metadata before operations
- Handle out-of-memory conditions

### Step 5: Testing Strategy

1. Basic Functionality Tests:
```c
void test_basic_allocation(void) {
    void *ptr = my_malloc(32);
    assert(ptr != NULL);
    my_free(ptr);
}
```

2. Size Tests:
```c
void test_various_sizes(void) {
    // Test minimum size
    void *p1 = my_malloc(1);  // Should align up
    
    // Test bucket boundary
    void *p2 = my_malloc(BUCKET_MIN_SIZE * 2);
    
    // Test large allocation
    void *p3 = my_malloc(1024 * 1024);
    
    my_free(p1);
    my_free(p2);
    my_free(p3);
}
```

3. Edge Cases:
```c
void test_edge_cases(void) {
    assert(my_malloc(0) == NULL);
    my_free(NULL);  // Should not crash
    
    // Test maximum size
    void *p = my_malloc(SIZE_MAX);
    assert(p == NULL);
}
```

