#include <criterion/criterion.h>
#include <criterion/logging.h>
#include <string.h>

#include "../src/bucket.h"

/*************************/
/* Basic malloc() Tests  */
/*************************/

Test(malloc_unit, null_malloc)
{
    void *ptr = my_malloc(0);
    cr_assert_null(ptr, "malloc(0) should return NULL");
}

Test(malloc_unit, basic_malloc)
{
    void *ptr = my_malloc(8);
    cr_assert_not_null(ptr, "malloc(8) should return a valid pointer");
    my_free(ptr);
}

Test(malloc_unit, write_to_malloc)
{
    char *str = my_malloc(12);
    cr_assert_not_null(str, "malloc failed");

    strcpy(str, "Hello");
    cr_assert_str_eq(str, "Hello", "Could not write to malloc'd memory");

    my_free(str);
}

Test(malloc_unit, small_malloc)
{
    void *ptr = my_malloc(1);
    cr_assert_not_null(ptr, "malloc(1) failed");
    my_free(ptr);
}

/*************************/
/* Basic free() Tests    */
/*************************/

Test(malloc_unit, null_free)
{
    my_free(NULL);
}

Test(malloc_unit, malloc_then_free)
{
    void *ptr = my_malloc(16);
    cr_assert_not_null(ptr, "malloc failed");
    my_free(ptr);
}

/*************************/
/* Basic calloc() Tests  */
/*************************/

Test(malloc_unit, basic_calloc)
{
    int *arr = my_calloc(4, sizeof(int));
    cr_assert_not_null(arr, "calloc failed");

    for (int i = 0; i < 4; i++)
        cr_assert_eq(arr[i], 0, "calloc memory not zeroed at index %d", i);

    my_free(arr);
}

Test(malloc_unit, zero_calloc)
{
    void *ptr = my_calloc(0, 4);
    cr_assert_null(ptr, "calloc with zero elements should return NULL");

    ptr = my_calloc(4, 0);
    cr_assert_null(ptr, "calloc with zero size should return NULL");
}

Test(malloc_unit, simple_calloc)
{
    char *str = my_calloc(10, 1);
    cr_assert_not_null(str, "calloc failed");
    cr_assert_eq(str[0], 0, "First byte not zero");
    cr_assert_eq(str[9], 0, "Last byte not zero");
    my_free(str);
}

/*************************/
/* Basic realloc() Tests */
/*************************/

Test(malloc_unit, null_realloc)
{
    void *ptr = my_realloc(NULL, 8);
    cr_assert_not_null(ptr, "realloc(NULL, 8) should act like malloc");
    my_free(ptr);
}

Test(malloc_unit, zero_realloc)
{
    void *ptr = my_malloc(8);
    cr_assert_not_null(ptr, "malloc failed");

    void *new_ptr = my_realloc(ptr, 0);
    cr_assert_null(new_ptr, "realloc to size 0 should return NULL");
}

Test(malloc_unit, simple_realloc_bigger)
{
    char *str = my_malloc(6);
    cr_assert_not_null(str, "malloc failed");

    strcpy(str, "Hello");
    str = my_realloc(str, 12);
    cr_assert_not_null(str, "realloc failed");
    cr_assert_str_eq(str, "Hello", "Data lost during realloc");

    my_free(str);
}

/*************************/
/* Basic Chain Tests     */
/*************************/

Test(malloc_unit, chain_allocations)
{
    int *a = my_malloc(sizeof(int));
    int *b = my_malloc(sizeof(int));
    int *c = my_malloc(sizeof(int));

    cr_assert_not_null(a, "First malloc failed");
    cr_assert_not_null(b, "Second malloc failed");
    cr_assert_not_null(c, "Third malloc failed");

    *a = 1;
    *b = 2;
    *c = 3;

    cr_assert_eq(*a, 1, "First value corrupted");
    cr_assert_eq(*b, 2, "Second value corrupted");
    cr_assert_eq(*c, 3, "Third value corrupted");

    my_free(a);
    my_free(b);
    my_free(c);
}

/*************************/
/* Basic Size Tests      */
/*************************/

Test(malloc_unit, different_sizes)
{
    char *p1 = my_malloc(8); // small
    char *p2 = my_malloc(256); // medium
    char *p3 = my_malloc(1024); // large

    cr_assert_not_null(p1, "Small allocation failed");
    cr_assert_not_null(p2, "Medium allocation failed");
    cr_assert_not_null(p3, "Large allocation failed");

    strcpy(p1, "test1");
    memset(p2, 'A', 255);
    p2[255] = '\0';
    memset(p3, 'B', 1023);
    p3[1023] = '\0';

    cr_assert_str_eq(p1, "test1", "Small buffer corrupted");
    cr_assert_eq(p2[0], 'A', "Medium buffer corrupted");
    cr_assert_eq(p2[254], 'A', "Medium buffer corrupted");
    cr_assert_eq(p3[0], 'B', "Large buffer corrupted");
    cr_assert_eq(p3[1022], 'B', "Large buffer corrupted");

    my_free(p1);
    my_free(p2);
    my_free(p3);
}

/*************************/
/* Basic Reuse Tests     */
/*************************/

Test(malloc_unit, simple_reuse)
{
    void *p1 = my_malloc(8);
    cr_assert_not_null(p1, "First malloc failed");
    my_free(p1);

    void *p2 = my_malloc(8);
    cr_assert_not_null(p2, "Second malloc failed");
    my_free(p2);
}

/*************************/
/* Content Tests         */
/*************************/

Test(malloc_unit, content_preservation)
{
    int *arr = my_malloc(5 * sizeof(int));
    cr_assert_not_null(arr, "malloc failed");

    for (int i = 0; i < 5; i++)
        arr[i] = i + 1;

    // Verify content
    for (int i = 0; i < 5; i++)
        cr_assert_eq(arr[i], i + 1, "Content corrupted at index %d", i);

    my_free(arr);
}

/*************************/
/* String Tests          */
/*************************/

Test(malloc_unit, string_operations)
{
    char *str = my_malloc(16);
    cr_assert_not_null(str, "malloc failed");

    strcpy(str, "Hello");
    cr_assert_str_eq(str, "Hello", "String content incorrect");

    strcat(str, " World");
    cr_assert_str_eq(str, "Hello World", "String concatenation failed");

    my_free(str);
}

/*************************/
/* Basic Bucket Tests    */
/*************************/

Test(malloc_unit, sequential_small_allocs)
{
    void *ptrs[10];

    // Allocate 10 small blocks
    for (int i = 0; i < 10; i++)
    {
        ptrs[i] = my_malloc(16);
        cr_assert_not_null(ptrs[i], "Allocation %d failed", i);
    }

    // Free them in order
    for (int i = 0; i < 10; i++)
        my_free(ptrs[i]);
}

Test(malloc_unit, mixed_bucket_sizes)
{
    // Should hit different bucket sizes
    void *p1 = my_malloc(16); // Bucket 1
    void *p2 = my_malloc(32); // Bucket 2
    void *p3 = my_malloc(64); // Bucket 3

    cr_assert_not_null(p1, "Small bucket allocation failed");
    cr_assert_not_null(p2, "Medium bucket allocation failed");
    cr_assert_not_null(p3, "Large bucket allocation failed");

    my_free(p1);
    my_free(p2);
    my_free(p3);
}
