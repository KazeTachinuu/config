# Memory Allocator Core Concepts - A Complete Guide

## 1. What is Memory Allocation?

### The Basics
Imagine your computer's memory as a very long bookshelf. When a program needs to store data:
- It needs to find empty "shelf space" (memory)
- It needs to know how much space it took (size)
- It needs to remember where that space is (address)
- It needs to be able to give that space back when done (free)

### Why Build a Custom Allocator?
The standard malloc is like a general-purpose storage service. Sometimes, you want a specialized service that:
- Is faster for specific use cases
- Has better memory usage patterns
- Provides special features
- Helps avoid fragmentation
- Gives you more control

## 2. Memory Pages

### What is a Memory Page?
- A page is the smallest unit of memory that the operating system manages
- Think of it like a standard-sized container that the OS uses
- Typically 4KB (4096 bytes) on most systems
- We get pages from the operating system using `mmap`

Example:
```c
// Getting the system's page size
size_t pagesize = sysconf(_SC_PAGESIZE);  // Usually 4096 bytes

// Requesting a new page from the system
void* new_page = mmap(NULL, pagesize, 
                     PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, 
                     -1, 0);
```

## 3. The Bucket System

### What are Buckets?
Imagine you're organizing buttons:
- You have small, medium, and large containers
- Each container holds buttons of similar sizes
- When you need a button, you go to the right container

In our allocator:
- Each bucket handles a specific size range
- Bucket sizes typically double: 16B, 32B, 64B, etc.
- Small allocations go to small buckets
- Large allocations get special treatment

### Bucket Structure
```c
struct bucket {
    size_t chunksize;    // Size of each piece in this bucket
    void *bucket;        // The actual memory area
    unsigned char bitmap[BITMAP_SIZE];  // Usage tracking
    struct bucket *next; // Next bucket of same size
    size_t used_chunks; // How many pieces are used
};
```

## 4. The Bitmap System

### What is a Bitmap?
Think of a bitmap like a parking lot map:
- Each spot represents a chunk of memory
- 0 means the spot is free
- 1 means the spot is taken

Example:
```
Bitmap: 10110000
Means:
✓ ✗ ✓ ✓ ✗ ✗ ✗ ✗
1 0 1 1 0 0 0 0
```

### How We Use It
```c
// To mark a chunk as used:
bucket->bitmap[byte_index] |= (1 << bit_index);

// To mark a chunk as free:
bucket->bitmap[byte_index] &= ~(1 << bit_index);

// To check if a chunk is used:
if (bucket->bitmap[byte_index] & (1 << bit_index))
```

## 5. Memory Alignment

### What is Alignment?
Imagine a ruler where you can only place stickers at certain marks:
- Some CPU instructions require data at specific addresses
- Usually powers of 2: 2, 4, 8, 16 bytes
- Improper alignment can cause crashes or slowdowns

### Why Align?
1. **Performance**: CPUs work better with aligned data
2. **Requirements**: Some data types need alignment
3. **Compatibility**: Some systems require alignment

Example:
```c
// Aligning a size to 8 bytes
size_t align_8(size_t size) {
    return (size + 7) & ~7;
}

// Better, safer version:
size_t align_size(size_t size, size_t alignment) {
    if (size == 0) return 0;
    size_t remainder = size % alignment;
    if (remainder == 0) return size;
    return size + (alignment - remainder);
}
```

## 6. Thread Safety

### What is Thread Safety?
Imagine multiple chefs in a kitchen:
- They all need to use the same refrigerator
- They need to coordinate to avoid conflicts
- They need to know when it's safe to access things

### How We Implement It
1. **Mutex Locks**: Like a kitchen "in use" sign
```c
pthread_mutex_t large_lock = PTHREAD_MUTEX_INITIALIZER;

// Before accessing shared resource
pthread_mutex_lock(&large_lock);

// After finishing
pthread_mutex_unlock(&large_lock);
```

2. **Per-Bucket Operations**: Each bucket can be used independently

## 7. Memory Chunks

### What are Chunks?
Think of chunks like storage boxes:
- Each bucket contains multiple chunks
- All chunks in a bucket are the same size
- Chunks are our basic unit of allocation

### Managing Chunks
```c
// Number of chunks in each bucket
#define CHUNKS_PER_BUCKET 2048

// Finding a chunk's index
size_t chunk_index = (ptr - bucket->start) / bucket->chunksize;

// Getting a chunk's address
void* chunk_addr = bucket->start + (chunk_index * bucket->chunksize);
```

## 8. Large Allocations

### What are Large Allocations?
- Requests bigger than our largest bucket
- Handled differently from bucket allocations
- Get their own dedicated memory pages

### Large Allocation Structure
```c
struct block_meta {
    size_t size;          // How big is this block?
    struct block_meta *next;  // Next large block
    char data[];          // The actual data area
};
```

## 9. Memory Statistics

### Why Track Statistics?
- Helps debug memory issues
- Monitors memory usage
- Identifies memory leaks
- Helps optimize allocation patterns

### What We Track
```c
struct allocator {
    // ... other fields ...
    size_t total_allocated;  // Current memory in use
    size_t peak_memory;      // Highest memory usage seen
};
```

## 10. Putting It All Together

### The Allocation Process
1. **Request Comes In**
   - Program asks for memory
   - We determine size needed

2. **Size Classification**
   - Is it a small or large request?
   - Which bucket size fits best?

3. **Memory Provision**
   - For small: Find/create bucket, get chunk
   - For large: Allocate new block

4. **Bookkeeping**
   - Update bitmap
   - Update statistics
   - Return memory to user

### The Deallocation Process
1. **Find the Block**
   - Is it in a bucket?
   - Is it a large allocation?

2. **Mark as Free**
   - Update bitmap for buckets
   - Release pages for large blocks

3. **Update Statistics**
   - Decrease allocated count
   - Maintain other metrics

## 11. Safe Programming Practices

### Overflow Protection
Always check for arithmetic overflow:
```c
static inline size_t size_add(size_t a, size_t b) {
    size_t result;
    if (__builtin_add_overflow(a, b, &result))
        return 0;  // Indicates overflow
    return result;
}
```

### Pointer Safety
Always validate pointer operations:
```c
static inline void *ptr_offset(void *ptr, size_t offset) {
    if (!ptr) return NULL;
    return (char*)ptr + offset;
}
```

### Error Handling
Always check for errors:
```c
void *chunk = mmap(NULL, size, PROT_READ | PROT_WRITE,
                  MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
if (chunk == MAP_FAILED)
    return NULL;  // Handle error
```

## 12. Testing Your Allocator

### Basic Tests
1. **Allocation Tests**
   - Can allocate different sizes
   - Returns aligned memory
   - Handles zero size correctly

2. **Free Tests**
   - Can free allocated memory
   - Handles NULL correctly
   - No memory leaks

3. **Edge Cases**
   - Very small allocations
   - Very large allocations
   - Maximum size requests

### Advanced Tests
1. **Stress Testing**
   - Many allocations/frees
   - Different allocation patterns
   - Threading tests

2. **Error Cases**
   - Out of memory
   - Invalid frees
   - Double frees

## Next Steps

1. Start with implementing basic utilities
2. Add simple bucket management
3. Implement small allocations
4. Add large allocation support
5. Add thread safety
6. Implement comprehensive testing
7. Profile and optimize

Remember: Take it step by step, test thoroughly, and always prioritize correctness over speed initially.
