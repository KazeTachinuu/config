#ifndef UTILS_H
#define UTILS_H

#include <stddef.h>

/*
 * Safe Pointer Utilities
 * --------------------
 * These functions provide safe pointer manipulation operations
 * All pointer arithmetic must go through these functions
 */

/* Safe const void* to void* conversion
 * Uses union to avoid compiler warnings */
static inline void *ptr_to_ptr(const void *ptr)
{
    union
    {
        const void *in;
        void *out;
    } convert = { .in = ptr };
    return convert.out;
}

/* Safe pointer offsetting
 * Returns NULL if inputs invalid */
static inline void *ptr_offset(void *ptr, size_t offset)
{
    if (!ptr)
        return NULL;
    union
    {
        void *ptr;
        char *as_char;
    } convert = { .ptr = ptr };
    return ptr_to_ptr(convert.as_char + offset);
}

/* Safe pointer difference calculation
 * Returns distance between two pointers */
static inline size_t ptr_diff(const void *end, const void *start)
{
    if (!end || !start)
        return 0;
    union
    {
        const void *ptr;
        const char *as_char;
    } end_u = { .ptr = end }, start_u = { .ptr = start };
    return end_u.as_char - start_u.as_char;
}

/*
 * Safe Arithmetic Operations
 * -----------------------
 * These functions prevent integer overflow
 * Return 0 if overflow would occur
 */

/* Safe addition - prevents overflow */
static inline size_t size_add(size_t a, size_t b)
{
    size_t result;
    if (__builtin_add_overflow(a, b, &result))
        return 0;
    return result;
}

/* Safe multiplication - prevents overflow */
static inline size_t size_mul(size_t a, size_t b)
{
    size_t result;
    if (__builtin_mul_overflow(a, b, &result))
        return 0;
    return result;
}

/* Memory alignment to CPU requirements */
static inline size_t align_size(size_t size, size_t alignment)
{
    if (size == 0)
        return 0;
    size_t remainder = size % alignment;
    if (remainder == 0)
        return size;

    size_t padding = alignment - remainder;
    size_t result;
    if (__builtin_add_overflow(size, padding, &result))
        return 0;
    return result;
}

#endif /* !UTILS_H */
