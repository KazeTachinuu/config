#ifndef UTILS_H
#define UTILS_H

#include "bucket.h"

/* Safe const void* to void* conversion */
static inline void *ptr_to_ptr(const void *ptr)
{
    union
    {
        const void *in;
        void *out;
    } convert = { .in = ptr };
    return convert.out;
}

/* Safe pointer offset calculation */
static inline void *ptr_offset(void *ptr, size_t offset)
{
    union
    {
        void *ptr;
        char *as_char;
    } convert = { .ptr = ptr };
    return ptr_to_ptr(convert.as_char + offset);
}

/* Safe pointer difference calculation */
static inline size_t ptr_diff(const void *end, const void *start)
{
    union
    {
        const void *ptr;
        const char *as_char;
    } end_u = { .ptr = end };

    union
    {
        const void *ptr;
        const char *as_char;
    } start_u = { .ptr = start };

    return end_u.as_char - start_u.as_char;
}

/* Safe size addition with overflow check */
static inline size_t size_add(size_t a, size_t b)
{
    size_t result;
    if (__builtin_add_overflow(a, b, &result))
        return 0;
    return result;
}

/* Safe size multiplication with overflow check */
static inline size_t size_mul(size_t a, size_t b)
{
    size_t result;
    if (__builtin_mul_overflow(a, b, &result))
        return 0;
    return result;
}

/* Safe alignment calculation */
static inline size_t align_size(size_t size, size_t alignment)
{
    if (size == 0)
        return 0;

    size_t remainder = size % alignment;

    if (remainder == 0)
        return size;

    size_t padding = alignment - remainder;

    if (__builtin_add_overflow(size, padding, &size))
        return 0;

    return size;
}

#endif /* !UTILS_H */
