#ifndef BUCKET_H
#define BUCKET_H

#define _GNU_SOURCE

#include <pthread.h>
#include <stddef.h>

#define BUCKET_MIN_SIZE 16
#define BUCKET_COUNT 11
#define BITMAP_SIZE 256
#define CHUNKS_PER_BUCKET 2048

struct block_meta
{
    size_t size;
    struct block_meta *next;
    char data[];
};

struct bucket
{
    size_t chunksize;
    void *bucket;
    unsigned char bitmap[BITMAP_SIZE];
    struct bucket *next;
    size_t used_chunks;
};

struct allocator
{
    size_t pagesize;
    struct bucket *buckets[BUCKET_COUNT];
    pthread_mutex_t large_lock;
    size_t total_allocated;
    size_t peak_memory;
};

// Function declarations
void *my_malloc(size_t size);
void my_free(void *ptr);
void *my_calloc(size_t nmemb, size_t size);
void *my_realloc(void *ptr, size_t size);

#endif /* !BUCKET_H */
