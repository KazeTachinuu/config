#ifndef BUCKET_H
#define BUCKET_H

#include <pthread.h>
#include <stddef.h>

/*
 * Configuration Constants
 * ---------------------
 * These values determine the behavior and efficiency of our allocator:
 *
 * BUCKET_MIN_SIZE: Smallest allocation size (16 bytes)
 *   - Must be a power of 2
 *   - Should accommodate common small allocations
 *
 * BUCKET_COUNT: Number of different bucket sizes (11)
 *   - Each bucket handles allocations of: MIN_SIZE * (2^bucket_index)
 *   - Example: Bucket 0 = 16B, Bucket 1 = 32B, Bucket 2 = 64B, etc.
 *
 * BITMAP_SIZE: Size of usage bitmap in bytes (256)
 *   - Each bit represents one chunk
 *   - 256 bytes * 8 bits = 2048 chunks can be tracked
 *
 * CHUNKS_PER_BUCKET: Number of chunks in each bucket (2048)
 *   - Must match the number of bits in bitmap
 *   - More chunks = better memory reuse but more overhead
 */
#define BUCKET_MIN_SIZE 16
#define BUCKET_COUNT 11
#define BITMAP_SIZE 256
#define CHUNKS_PER_BUCKET 2048

/*
 * Large Allocation Metadata
 * -----------------------
 * Used for allocations larger than our biggest bucket can handle
 * The flexible array member (data[]) allows the actual allocation
 * to be placed immediately after the metadata
 */
struct block_meta
{
    size_t size; // Size of the allocation
    struct block_meta *next; // Next large block in chain
    char data[]; // Actual allocation starts here
};

/*
 * Bucket Structure
 * ---------------
 * Each bucket manages memory chunks of a specific size
 * Multiple buckets of the same size can exist in a linked list
 */
struct bucket
{
    size_t chunksize; // Size of each chunk in this bucket
    void *bucket; // Pointer to the actual memory area
    unsigned char bitmap[BITMAP_SIZE]; // Usage bitmap (1 = used, 0 = free)
    struct bucket *next; // Next bucket of same size
    size_t used_chunks; // Number of chunks currently in use
};

/*
 * Main Allocator Structure
 * ----------------------
 * Global state for our memory allocator
 * Maintains list of buckets and tracks memory usage
 */
struct allocator
{
    size_t pagesize; // System page size (usually 4096)
    struct bucket *buckets[BUCKET_COUNT]; // Array of bucket lists
    pthread_mutex_t large_lock; // Mutex for thread-safe large allocations
    size_t total_allocated; // Total memory currently allocated
    size_t peak_memory; // Peak memory usage observed
};

/* Main interface functions - matches standard malloc interface */
void *my_malloc(size_t size);
void my_free(void *ptr);
void *my_calloc(size_t nmemb, size_t size);
void *my_realloc(void *ptr, size_t size);

#endif /* !BUCKET_H */
