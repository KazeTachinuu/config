#include "bucket.h"

#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#include "utils.h"

static struct allocator mgr = { .pagesize = 0,
                                .buckets = { [0] = NULL },
                                .large_lock = PTHREAD_MUTEX_INITIALIZER,
                                .total_allocated = 0,
                                .peak_memory = 0 };

/**
** Allocates metadata page for a new bucket
** Returns NULL on failure
*/
static struct bucket *allocate_meta_page(void)
{
    struct bucket *meta = mmap(NULL, mgr.pagesize, PROT_READ | PROT_WRITE,
                               MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (meta == MAP_FAILED)
        return NULL;
    return meta;
}

/**
** Allocates chunk area for a bucket
** Returns NULL on failure
*/
static void *allocate_chunk_area(size_t total_size)
{
    void *chunk = mmap(NULL, total_size, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (chunk == MAP_FAILED)
        return NULL;
    return chunk;
}

/**
** Initialize bucket metadata and memory
*/
static int init_bucket_memory(struct bucket *meta, size_t size,
                              size_t total_size)
{
    void *chunk = allocate_chunk_area(total_size);
    if (chunk == NULL)
    {
        munmap(meta, mgr.pagesize);
        return 1;
    }

    meta->chunksize = size;
    meta->used_chunks = 0;
    memset(meta->bitmap, 0, BITMAP_SIZE);
    meta->next = NULL;
    meta->bucket = chunk;

    return 0;
}

/**
** Initialize a new bucket
*/
static int init_bucket(struct bucket *prev, size_t i, size_t size)
{
    if (mgr.pagesize == 0)
        mgr.pagesize = sysconf(_SC_PAGESIZE);

    size = align_size(size, sizeof(long double));
    if (!size)
        return 1;

    size_t total_chunks = size_mul(CHUNKS_PER_BUCKET, size);
    if (total_chunks == 0)
        return 1;

    size_t nbpages = (total_chunks + mgr.pagesize - 1) / mgr.pagesize;
    size_t total_size = size_mul(nbpages, mgr.pagesize);
    if (total_size == 0)
        return 1;

    struct bucket *meta = allocate_meta_page();
    if (meta == NULL)
        return 1;

    if (init_bucket_memory(meta, size, total_size))
        return 1;

    if (prev)
        prev->next = meta;
    else
        mgr.buckets[i] = meta;

    return 0;
}

/**
** Find and set available chunk in bitmap
*/
static void *find_and_set_chunk(struct bucket *bucket, size_t i, size_t j)
{
    bucket->bitmap[i] |= (1 << j);
    bucket->used_chunks++;

    size_t chunk_index = (i * 8) + j;
    size_t offset = size_mul(chunk_index, bucket->chunksize);
    if (chunk_index != 0 && !offset)
        return NULL;

    return ptr_offset(bucket->bucket, offset);
}

/**
** Get a chunk from bucket's bitmap
*/
static void *get_chunk_from_bucket(struct bucket *bucket)
{
    if (bucket == NULL || bucket->used_chunks >= CHUNKS_PER_BUCKET)
        return NULL;

    for (size_t i = 0; i < BITMAP_SIZE; i++)
    {
        if (bucket->bitmap[i] != 0xFF)
        {
            for (size_t j = 0; j < 8; j++)
            {
                if (!(bucket->bitmap[i] & (1 << j)))
                    return find_and_set_chunk(bucket, i, j);
            }
        }
    }
    return NULL;
}

/**
** Get bucket index for given size
*/
static size_t get_bucket_index(size_t size)
{
    if (size <= BUCKET_MIN_SIZE)
        return 0;

    size_t index = 0;
    size_t curr_size = BUCKET_MIN_SIZE;

    while (curr_size < size && index < BUCKET_COUNT - 1)
    {
        curr_size *= 2;
        index++;
    }

    return index;
}

/**
** Allocate memory block for large allocations
*/
static void *allocate_large_block(size_t size)
{
    size_t meta_size =
        align_size(sizeof(struct block_meta), sizeof(long double));
    size_t total_size = size_add(meta_size, size);
    if (total_size == 0)
        return NULL;

    total_size = align_size(total_size, mgr.pagesize);
    if (total_size == 0)
        return NULL;

    void *block = mmap(NULL, total_size, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    if (block == MAP_FAILED)
        return NULL;

    struct block_meta *meta = block;
    meta->size = size;
    meta->next = NULL;

    return ptr_offset(block, meta_size);
}

/**
** Try to get a chunk from existing bucket
*/
static void *try_existing_bucket(struct bucket *current)
{
    if (current->used_chunks < CHUNKS_PER_BUCKET)
    {
        void *chunk = get_chunk_from_bucket(current);
        if (chunk)
        {
            size_t chunk_index =
                ptr_diff(chunk, current->bucket) / current->chunksize;
            size_t byte_index = chunk_index / 8;
            size_t bit_index = chunk_index % 8;
            current->bitmap[byte_index] &= ~(1 << bit_index);
            current->used_chunks--;
            return current;
        }
    }
    return NULL;
}

/**
** Find or create a bucket for given size
*/
static struct bucket *find_bucket(size_t size)
{
    if (mgr.pagesize == 0)
        mgr.pagesize = sysconf(_SC_PAGESIZE);

    size_t index = get_bucket_index(size);
    struct bucket *current = mgr.buckets[index];
    struct bucket *prev = NULL;

    while (current)
    {
        void *result = try_existing_bucket(current);
        if (result)
            return current;
        prev = current;
        current = current->next;
    }

    size_t bucket_size = BUCKET_MIN_SIZE << index;
    if (init_bucket(prev, index, bucket_size))
        return NULL;

    return prev ? prev->next : mgr.buckets[index];
}

/**
** Update allocation statistics
*/
static void update_stats(size_t size)
{
    size_t new_total = size_add(mgr.total_allocated, size);
    if (new_total)
    {
        mgr.total_allocated = new_total;
        if (mgr.total_allocated > mgr.peak_memory)
            mgr.peak_memory = mgr.total_allocated;
    }
}

/**
** Allocate memory
*/
void *my_malloc(size_t size)
{
    if (size == 0)
        return NULL;

    size = align_size(size, sizeof(long double));
    if (size == 0)
        return NULL;

    void *ptr;
    size_t max_bucket_size = BUCKET_MIN_SIZE << (BUCKET_COUNT - 1);

    if (size > max_bucket_size)
    {
        pthread_mutex_lock(&mgr.large_lock);
        ptr = allocate_large_block(size);
        pthread_mutex_unlock(&mgr.large_lock);
    }
    else
    {
        struct bucket *bucket = find_bucket(size);
        if (bucket == NULL)
            return NULL;
        ptr = get_chunk_from_bucket(bucket);
    }

    if (ptr)
        update_stats(size);

    return ptr;
}

/**
** Handle free for bucket allocation
*/
static int handle_bucket_free(struct bucket *bucket, void *ptr)
{
    size_t total_size = size_mul(bucket->chunksize, CHUNKS_PER_BUCKET);
    if (total_size == 0)
        return 0;

    if (ptr >= bucket->bucket && ptr < ptr_offset(bucket->bucket, total_size))
    {
        size_t offset = ptr_diff(ptr, bucket->bucket);
        size_t chunk_index = offset / bucket->chunksize;

        if (chunk_index >= CHUNKS_PER_BUCKET)
            return 0;

        size_t byte_index = chunk_index / 8;
        size_t bit_index = chunk_index % 8;

        if ((bucket->bitmap[byte_index] & (1 << bit_index)) == 0)
            return 0;

        bucket->bitmap[byte_index] &= ~(1 << bit_index);
        bucket->used_chunks--;
        mgr.total_allocated = size_add(mgr.total_allocated, -bucket->chunksize);
        return 1;
    }
    return 0;
}

/**
** Handle free for large allocation
*/
static void handle_large_free(void *ptr)
{
    void *meta_ptr = ptr_offset(
        ptr, -align_size(sizeof(struct block_meta), sizeof(long double)));
    if (meta_ptr == NULL)
        return;

    struct block_meta *block = meta_ptr;
    size_t total_size =
        size_add(align_size(sizeof(struct block_meta), sizeof(long double)),
                 block->size);
    if (total_size == 0)
        return;

    total_size = align_size(total_size, mgr.pagesize);
    if (total_size)
    {
        mgr.total_allocated = size_add(mgr.total_allocated, -block->size);
        munmap(meta_ptr, total_size);
    }
}

/**
** Free memory allocated by malloc/realloc/calloc
*/
void my_free(void *ptr)
{
    if (ptr == NULL)
        return;

    for (size_t i = 0; i < BUCKET_COUNT; i++)
    {
        struct bucket *bucket = mgr.buckets[i];
        while (bucket)
        {
            if (handle_bucket_free(bucket, ptr))
                return;
            bucket = bucket->next;
        }
    }

    pthread_mutex_lock(&mgr.large_lock);
    handle_large_free(ptr);
    pthread_mutex_unlock(&mgr.large_lock);
}

/**
** Handle realloc for bucket allocation
*/
static void *handle_bucket_realloc(struct bucket *bucket, void *ptr,
                                   size_t size)
{
    size_t bucket_size = size_mul(CHUNKS_PER_BUCKET, bucket->chunksize);
    if (bucket_size == 0)
        return NULL;

    void *bucket_end = ptr_offset(bucket->bucket, bucket_size);
    if (bucket_end == NULL || ptr < bucket->bucket || ptr >= bucket_end)
        return NULL;

    void *new_ptr = my_malloc(size);
    if (new_ptr == NULL)
        return NULL;

    memcpy(new_ptr, ptr, size < bucket->chunksize ? size : bucket->chunksize);
    my_free(ptr);
    return new_ptr;
}

/**
** Handle realloc for large allocation
*/
static void *handle_large_realloc(void *ptr, size_t size)
{
    void *meta_ptr = ptr_offset(ptr, -(sizeof(struct block_meta)));
    if (meta_ptr == NULL)
        return NULL;

    struct block_meta *block = meta_ptr;
    if (size <= block->size)
        return ptr;

    void *new_ptr = my_malloc(size);
    if (new_ptr == NULL)
        return NULL;

    memcpy(new_ptr, ptr, block->size);
    my_free(ptr);
    return new_ptr;
}

/**
** Change the size of previously allocated memory
*/
void *my_realloc(void *ptr, size_t size)
{
    if (ptr == NULL)
        return my_malloc(size);

    if (size == 0)
    {
        my_free(ptr);
        return NULL;
    }

    for (size_t i = 0; i < BUCKET_COUNT; i++)
    {
        struct bucket *bucket = mgr.buckets[i];
        while (bucket)
        {
            void *result = handle_bucket_realloc(bucket, ptr, size);
            if (result)
                return result;
            bucket = bucket->next;
        }
    }

    return handle_large_realloc(ptr, size);
}

/**
** Allocate zeroed memory
*/
void *my_calloc(size_t nmemb, size_t size)
{
    if (nmemb == 0 || size == 0)
        return NULL;

    size_t total = size_mul(nmemb, size);
    if (total == 0)
        return NULL;

    void *ptr = my_malloc(total);
    if (ptr)
        memset(ptr, 0, total);

    return ptr;
}
