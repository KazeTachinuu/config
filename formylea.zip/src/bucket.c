#include "bucket.h"

#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#include "utils.h"

/* Global allocator instance */
static struct allocator mgr = { .pagesize = 0,
                                .buckets = { [0] = NULL },
                                .large_lock = PTHREAD_MUTEX_INITIALIZER,
                                .total_allocated = 0,
                                .peak_memory = 0 };

/*
 * Bucket Management Functions
 * -------------------------
 * These handle creation and initialization of buckets
 */

/* Allocates a new metadata page for bucket
 * TODO: Implementation steps:
 * 1. Use mmap to allocate a page
 * 2. Set protection flags (PROT_READ | PROT_WRITE)
 * 3. Use MAP_PRIVATE | MAP_ANONYMOUS for flags
 * 4. Check for MAP_FAILED
 */
static struct bucket *allocate_meta_page(void)
{
    if (mgr.pagesize == 0)
        mgr.pagesize = sysconf(_SC_PAGESIZE);

    // Your implementation here
}

/* Allocates memory area for chunks
 * TODO: Implementation steps:
 * 1. Use mmap like above
 * 2. Ensure alignment
 * 3. Handle errors
 */
static void *allocate_chunk_area(size_t total_size)
{
    // Your implementation here
}

/* Initialize a new bucket's memory
 * TODO: Implementation steps:
 * 1. Allocate chunk area
 * 2. Initialize metadata fields
 * 3. Clear bitmap
 * 4. Handle errors
 */
static int init_bucket_memory(struct bucket *meta, size_t size,
                              size_t total_size)
{
    void *chunk = allocate_chunk_area(total_size);
    if (!chunk)
    {
        munmap(meta, mgr.pagesize);
        return 1;
    }

    // Basic initialization provided
    meta->chunksize = size;
    meta->used_chunks = 0;
    memset(meta->bitmap, 0, BITMAP_SIZE);
    meta->next = NULL;
    meta->bucket = chunk;

    return 0;
}

/*
 * Memory Allocation Implementation
 * -----------------------------
 * Core functions that handle memory allocation
 */

/* Main allocation function
 * TODO: Implementation steps:
 * 1. Handle special cases (size = 0)
 * 2. Align size to proper boundary
 * 3. Choose between bucket/large allocation
 * 4. For bucket allocation:
 *    - Find appropriate bucket
 *    - Get free chunk
 *    - Update bitmap
 * 5. For large allocation:
 *    - Use mmap directly
 *    - Add metadata
 * 6. Update statistics
 */
void *my_malloc(size_t size)
{
    // Your implementation here
}

/* Memory deallocation
 * TODO: Implementation steps:
 * 1. Handle NULL pointer
 * 2. Find correct bucket/block
 * 3. For bucket allocation:
 *    - Clear bitmap bit
 *    - Update used_chunks
 * 4. For large allocation:
 *    - Use munmap
 * 5. Update statistics
 */
void my_free(void *ptr)
{
    // Your implementation here
}

/* Zeroed memory allocation
 * Basic implementation provided */
void *my_calloc(size_t nmemb, size_t size)
{
    if (nmemb == 0 || size == 0)
        return NULL;

    size_t total = size_mul(nmemb, size);
    if (total == 0)
        return NULL;

    void *ptr = my_malloc(total);
    if (ptr)
        memset(ptr, 0, total);

    return ptr;
}

/* Memory reallocation
 * TODO: Implementation steps:
 * 1. Handle special cases (NULL ptr, size 0)
 * 2. Find current allocation
 * 3. If new size <= current size, return ptr
 * 4. Otherwise:
 *    - Allocate new block
 *    - Copy data
 *    - Free old block
 */
void *my_realloc(void *ptr, size_t size)
{
    // Your implementation here
}

/* Helper Functions */

/* Update allocation statistics */
static void update_stats(size_t size)
{
    size_t new_total = size_add(mgr.total_allocated, size);
    if (new_total)
    {
        mgr.total_allocated = new_total;
        if (mgr.total_allocated > mgr.peak_memory)
            mgr.peak_memory = mgr.total_allocated;
    }
}

/* Calculate bucket index for size */
static size_t get_bucket_index(size_t size)
{
    if (size <= BUCKET_MIN_SIZE)
        return 0;

    size_t index = 0;
    size_t curr_size = BUCKET_MIN_SIZE;

    while (curr_size < size && index < BUCKET_COUNT - 1)
    {
        curr_size *= 2;
        index++;
    }

    return index;
}
